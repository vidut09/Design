/**
 * 
 */
/**
 * 
 */
module Delegation {
}